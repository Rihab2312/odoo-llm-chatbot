{
    'name': 'Odoo Internal Chatbot',
    'version': '1.0',
    'summary': 'Chatbot interne intégré à Odoo',
    'category': 'Tools',
    'author': 'Rihab RIHANI',
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',
        'security/security_role_chatbot.xml',
        'views/chatbot_view.xml',
    ],
    'installable': True,
    'application': True,
}
