from odoo import models, fields, api
from datetime import datetime
import logging
import spacy
import os
_logger = logging.getLogger(__name__)

class ChatBot(models.Model):
    _name = 'chat.bot'
    _description = 'Chatbot avec NLP'

    # Les champs de la vue
    name = fields.Char(string="Requête", required=True)
    response = fields.Html(string="Réponse", readonly=True)

    # Attribut de classe pour stocker le modèle NLP
    nlp_model = None

    @api.model
    def _initialize_nlp(self):
        """Initialise le modèle NLP une seule fois pour l'ensemble de la classe."""
        if ChatBot.nlp_model is None:  # Vérifie si le modèle n'est pas déjà chargé
            try:
                ChatBot.nlp_model = spacy.load('en_core_web_sm')
                print("Modèle spaCy chargé avec succès.")
            except OSError as e:
                ChatBot.nlp_model = None
                print(f"Erreur lors du chargement du modèle NLP : {e}")

    def action_get_response(self):
        """Traite la requête utilisateur."""
        # Initialiser le NLP si ce n'est pas déjà fait
        self._initialize_nlp()

        for record in self:
            if not record.name:
                record.response = "Veuillez entrer une requête."
                continue

            if ChatBot.nlp_model:
                record.response = record.process_query(record.name)
            else:
                record.response = "Erreur : le modèle NLP n'a pas pu être chargé."

    def process_query(self, query):
        query = query.lower().replace(",", "").replace(".", "")
        all_clients = self.env['res.partner'].search([]).mapped('name')
        # Liste des statuts possibles
        valid_states = ['brouillon', 'envoyé', 'confirmé', 'terminé', 'annulé']
        state_mapping = {
            'brouillon': 'draft',
            'envoyé': 'sent',
            'confirmé': 'sale',
            'terminé': 'done',
            'annulé': 'cancel'}

        response = "Je ne comprends pas votre demande."
        client_name = None
        doc = ChatBot.nlp_model(query)
        for ent in doc.ents:
            if ent.label_ in ["PERSON", "ORG"]:
                client_name = ent.text.strip()
                break
        # Recherche manuelle si NLP ne détecte pas le client
        if not client_name:
            for client in all_clients:
                if client.lower() in query:
                    client_name = client
                    break

        # Détecter les requêtes sur les commandes spécifiques par statut
        if any(state in query for state in valid_states):
            # Identifier le statut demandé
            state_filter = None
            for state in valid_states:
                if state in query:
                    state_filter = state_mapping[state]
                    break

            print(f"Client extrait : {client_name}, Statut extrait : {state_filter}")
            response = self._get_orders_by_state(client_name=client_name, state_filter=state_filter)

        # Détecter les requêtes pour les dernières factures
        elif "dernières factures" in query:
            # Extraire le nombre demandé dans la requête (par défaut : 5)
            count = 5  # Valeur par défaut
            words = query.split()
            for word in words:
                if word.isdigit():
                    count = int(word)
                    break

            print(f"Client extrait : {client_name}, Nombre demandé : {count}")
            response = self._get_last_invoices(client_name=client_name, count=count)

        # Détecter les requêtes de création de commandes
        elif "commande" in query or "crée" in query:
            products_with_qty = {}
            words = query.split()
            all_products = self.env['product.product'].search([]).mapped('name')
            i = 0
            while i < len(words):
                word = words[i]
                if word.isdigit():
                    qty = int(word)
                    if i + 1 < len(words):
                        product_candidate = words[i + 1]
                        for product in all_products:
                            if product_candidate.lower() in product.lower():
                                if product in products_with_qty:
                                    products_with_qty[product] += qty
                                else:
                                    products_with_qty[product] = qty
                                break
                    i += 2
                else:
                    i += 1

            print(f"Client : {client_name}, Produits avec quantités : {products_with_qty}")
            response = self._create_sale_order(client_name, products_with_qty)
        # Détecter les requêtes d'imprimer ou envoyer une facture
        elif "imprimer" in query and "facture" in query:
            # Extraire le numéro de la facture
            words = query.split()
            invoice_number = None
            for word in words:
                if "fac/" in word.lower():
                    invoice_number = word.upper()
                    break

            # Vérifier si un numéro de facture est trouvé
            if not invoice_number:
                response = "Veuillez spécifier un numéro de facture valide pour l'envoi par email."
            else:
                response = self._send_and_print_invoice(invoice_number)
        # ---- Basculer les pipelines vers un statut précis et ouvrir l'interface
        elif "bascule" in query and "pipeline" in query:
            # Liste des états possibles dans CLC
            all_stages = self.env['crm.stage'].search([]).mapped('name')
            print (all_stages,'all stage *************')
            # Extraction des étapes demandées
            words = query.split()
            current_stage = None
            new_stage = None

            for word in words:
                word_cap = word.capitalize()
                if word_cap in all_stages:
                    if not current_stage:
                        current_stage = word_cap
                    else:
                        new_stage = word_cap
                        break

            if current_stage and new_stage:
                response = self._update_pipeline_state(current_stage, new_stage)
            else:
                response = "Je n’ai pas pu identifier les étapes demandées. Veuillez reformuler la requête."

        # Enregistrer l'historique dans `chat.bot.history`
        self.env['chat.bot.history'].create({ 'timestamp': fields.Datetime.now(),'query': query,'response': response})
        # Retourner la réponse
        return response

    # ----- Créer sale order directement
    def _create_sale_order(self, client_name, products_with_qty):
        """Créer une commande pour un client avec les produits spécifiés."""
        if not client_name:
            return "Veuillez préciser le client."

        # Rechercher le client dans Odoo
        client = self.env['res.partner'].search([('name', 'ilike', client_name)], limit=1)
        if not client:
            return f"Client '{client_name}' introuvable."

        # Vérifier si des produits sont spécifiés
        if not products_with_qty:
            return f"Aucun produit spécifié pour la commande."

        # Préparer les lignes de commande
        order_lines = []
        for product_name, qty in products_with_qty.items():
            # Rechercher le produit dans Odoo avec une correspondance stricte
            product = self.env['product.product'].search([('name', '=', product_name)], limit=1)
            if not product:
                product = self.env['product.product'].search([('name', 'ilike', product_name)], limit=1)
            if not product:
                return f"Produit '{product_name}' introuvable. Veuillez vérifier l'existence du produit dans Odoo."
            existing_line = next((line for line in order_lines if line[2]['product_id'] == product.id), None)
            if existing_line:
                existing_line[2]['product_uom_qty'] += qty
            else:
                order_lines.append((0, 0, {
                    'product_id': product.id,
                    'product_uom_qty': qty,
                    'price_unit': product.lst_price,
                }))
        # Créer le bon de commande
        sale_order = self.env['sale.order'].create({
            'partner_id': client.id,
            'order_line': order_lines,
        })
        return f"Commande créée pour le client '{client.name}' avec les produits : {', '.join(products_with_qty.keys())}. " \
               f"<a href='/web#id={sale_order.id}&model=sale.order&view_type=form' target='_blank' " \
               f"style='font-weight: bold; text-decoration: underline; color: green;'>Voir la commande</a>"

    def _get_orders_by_state(self, client_name=None, state_filter=None):
        """
        Renvoie le nombre de commandes pour un état spécifique et un client donné.
        """
        # Liste des états valides dans le modèle 'sale.order'
        valid_states = ['draft', 'sent', 'sale', 'done', 'cancel']

        # Vérifier si state_filter est valide
        if state_filter and state_filter not in valid_states:
            return (
                f"L'état '{state_filter}' n'est pas valide. "
                f"Les états possibles sont : {', '.join(valid_states)}."
            )
        state_filter = state_filter or 'draft'
        domain = [('state', '=', state_filter)]
        if client_name:
            client = self.env['res.partner'].search([('name', 'ilike', client_name)], limit=1)
            if not client:
                return f"Le client '{client_name}' est introuvable."
            domain.append(('partner_id', '=', client.id))
        if not self.env['sale.order'].check_access_rights('read', raise_exception=False):
            return (
                "<div style='color: red; font-weight: normal; text-align: center;'>"
                "<span style='margin-right: 10px;'>❌</span>"
                "Vous n'avez pas les droits nécessaires pour accéder aux informations de commande !"
                "</div>"
            )
        orders_count = self.env['sale.order'].search_count(domain)
        if client_name:
            return f"Le client '{client_name}' a {orders_count} commande(s) avec l'état '{state_filter}'."
        return f"Il y a {orders_count} commande(s) avec l'état '{state_filter}'."

    # Get last invoices
    def _get_last_invoices(self, client_name=None, count=5):
        """
        Renvoie les dernières factures, soit globalement, soit pour un client spécifique.
        Le nombre de factures à retourner est défini par le paramètre 'count'.
        """
        # Construire le domaine de recherche
        domain = [('move_type', '=', 'out_invoice'), ('state', '=', 'posted')]  # Factures clients validées

        # Filtrer par client si un nom est fourni
        if client_name:
            client = self.env['res.partner'].search([('name', 'ilike', client_name)], limit=1)
            if not client:
                return f"Le client '{client_name}' est introuvable."
            domain.append(('partner_id', '=', client.id))

        # Rechercher les dernières factures correspondant au domaine
        invoices = self.env['account.move'].search(domain, order="date desc", limit=count)

        # Construire la réponse
        if not invoices:
            if client_name:
                return f"Aucune facture trouvée pour le client '{client_name}'."
            return "Aucune facture trouvée."

        if client_name:
            response = f"Les {count} dernières factures pour le client '{client_name}' :<br/>"
        else:
            response = f"Les {count} dernières factures globales :<br/>"

        # Ajouter les factures dans la réponse
        response += "<br/>".join(f"{inv.name} - {inv.date}" for inv in invoices)
        return response

    # Imprimer facture numéro X
    def _send_and_print_invoice(self, invoice_number):
        """
        Recherche une facture par son numéro et déclenche l'action 'send_and_print_action'
        pour l'envoyer et l'imprimer.
        """
        # Rechercher la facture par son numéro
        invoice = self.env['account.move'].search([('name', '=', invoice_number)], limit=1)
        # Vérifier si la facture existe
        if not invoice:
            return f"La facture '{invoice_number}' est introuvable."

        # Vérifier que le document est bien une facture client
        if not invoice.is_invoice(include_receipts=True):
            return f"Le document '{invoice_number}' n'est pas une facture client valide."

        # # Vérifier les droits d'accès
        # if not invoice.check_access_rights('read', raise_exception=False):
        #     return (
        #         "<div style='color: red; font-weight: normal; text-align: center;'>"
        #         "<span style='margin-right: 10px;'>❌</span>"
        #         "Vous n'avez pas les droits nécessaires pour envoyer et imprimer cette facture !"
        #         "</div>"
        #     )

        # Préparer l'envoi via le modèle 'account.invoice.send'
        # invoice_send = self.env['account.invoice.send'].create({'invoice_ids': [(6, 0, [invoice.id])]})
        # print (invoice_send,'invoice_send ********')
        # Appeler l'action 'send_and_print_action'
        try:
            # Appeler la méthode d'impression
            action = invoice.action_invoice_print()
            base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
            report_name = action.get('report_name')
            download_url = (f"{base_url}/report/pdf/{report_name}/{invoice.id}?download=true")
            return (
                f"La facture '{invoice_number}' a été imprimée avec succès. "
                f"<a href='{download_url}' target='_blank'>Télécharger le PDF</a>"
            )
        except Exception as e:
            return f"Erreur lors de la génération de la facture : {str(e)}"


    # Basculer les pipelines selon statut
    def _update_pipeline_state(self, current_stage, new_stage):
        """
        Met à jour l'état des opportunités CRM et ouvre directement l'interface CRM.
        """
        # Récupérer les IDs des étapes du pipeline
        current_stage_id = self.env['crm.stage'].search([('name', 'ilike', current_stage)], limit=1)
        print (current_stage_id,'current stage id')
        new_stage_id = self.env['crm.stage'].search([('name', 'ilike', new_stage)], limit=1)
        print (new_stage_id,'new stage id')

        if not current_stage_id or not new_stage_id:
            return f"L'une des étapes '{current_stage}' ou '{new_stage}' est introuvable."

        # Trouver les opportunités à mettre à jour
        opportunities = self.env['crm.lead'].search([('stage_id', '=', current_stage_id.id),(('type', '=', 'opportunity'))])

        if not opportunities:
            return f"Aucune opportunité trouvée dans l'étape '{current_stage}'."

        # Mise à jour des opportunités
        opportunities.write({'stage_id': new_stage_id.id})

        # Retourner une action pour ouvrir l'interface CRM
        return {
            'type': 'ir.actions.act_window',
            'name': 'Opportunités CRM',
            'res_model': 'crm.lead',
            'view_mode': 'kanban,tree,form',
            'target': 'current',
        }


class ChatBotHistory(models.Model):
    _name = 'chat.bot.history'
    _description = 'Historique des interactions du Chatbot'

    query = fields.Char(string="Requête")
    response = fields.Text(string="Réponse")
    timestamp = fields.Datetime(string="Date et heure", default=lambda: datetime.now())
